# Name That LLM 渠道对照采集（预算授权 v2）

此目录为实际采集交付；父目录 v1 零请求报告是旧预算条件下历史记录，已被用户新预算授权替代。

本次通过 Kaggle Model Proxy，独立于 Codex 订阅数据。仅原指定10个train提示词×2个目标模型，不用于训练、不提交比赛。输入原文件250题哈希在manifest中；Kaggle仅接收原文件精确选出的10题。

实际发送基础指令 Answer the user's request.，reasoning_effort=low，max_completion_tokens=1024，stream=false，n=1；temperature/seed省略，生效默认unknown，snapshot unknown。使用当前kbench 0.6.2中账号已有proxy client，仅原始chat.completions.create以保留原文/全部返回元数据；每次消息只有新system+user，不调用工具/搜索/裁判。

响应保存为responses.jsonl，每次写入flush/fsync后才推进下条，request-journal.jsonl保留开始和结束事件。source=kaggle_model_proxy。重复请求由提示词ID+请求模型+配置哈希识别；本次完成后不允许运行更多请求，后续未授权扩采。

所有内容按返回原文保留，未按字数截断、润色、去换行或筛选质量。length_anomaly使用原始目标字数的0.5至1.5倍作为诊断范围，非改写标准。completion_tokens_details缺失时推理token数为unknown，不能视为零。cost由平台usage.cost两项纳美元之和计算，不使用供应商报价。

正式EXP编号/台账登记待本地合并者完成，未猜测编号，未修改EXP004、Codex采集或其他实验。
