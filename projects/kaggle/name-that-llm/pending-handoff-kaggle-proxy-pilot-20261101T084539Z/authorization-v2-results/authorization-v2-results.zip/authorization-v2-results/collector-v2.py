import os, json, base64, gzip, hashlib, datetime, pathlib
ROOT=pathlib.Path('/kaggle/working/kaggle-proxy-pilot-20261101T084539Z')
ROOT.mkdir(exist_ok=True)
RAW=gzip.decompress(base64.b64decode('H4sIAAAAAAACA62XTW/jNhCG7/0Vg1z2khq2uwiMXBZB0aKLokDRD/QoUOJIYk2RKj+sqIv+975D2dlk42zT1pcAkSl65pl33hl/uBqDH8ZUGX11e9WM6/V6c3V9fIgn7yn2KjApcioEPxG7FOZJzTSZ1FOaPAXvh0EljteknMZ5z5H2zCPV1jd74zpKPZP2Pqzo59x1HBPuG4NqkmmUJVysXMcDrsZJlSjwH9kE3OI86WCslTt8IMcTtTk4k3LgFd2ZgVo8VrXPiXZrmnzQcYXwG4TT+TAjAT5wmLWaK6UPpmF8mFToOFXl8NXtbn3KtuqCz+NjCnG0RiCkoIyT/30OuOL2ygfTGads1XjN95XKqfeBdbVdb282G7z71xcfnoHdbh+D/eZ+tLiVpn4WGFlry9QoR9pENY6sAnmHTxrvLSF+QiIOeHzu+sJzQo6CBPkR8onUWB+ZkqfaGyG2oh8tKzxSLk44hC8L8radabM9Dys2hl3DFUtwTiXj3TNgePcssZLeZYm9/eoxse+gPi3aAi4Vo4RDA6LskBuuyg0XLo5ZC4UAQQ01PsOZ+eGNo0inRWZx9C6aGrjSTDFBafIaQo+LvA2w5sjhHd2dTjP5For1Gbdsbo4YyUQ0hsD9BGjipnfe+m7+PNOb80wLgMsyvXn7mOkdxOL3MeE9CMqJijL+GzhEYQgtNl4Ell2rBmCCKpevWQBJ3w2qtLigij3bAwqkTduaJtskdzh1MB2IQI7BjyJRRQMChgkACQcjfb+i78UwZqT2EbSTJtiuz0u1ztE4jrHS3Jh4DirePAu1ELgs1N3mpdbujcA1aEGBmUAqm9iXvnaJh9EHFWZ8JH9bXCBwePAm0BRMSmh55Ke0qL6VfheFixMkCPlUAUg7D1IDxgOcWXIRTSJ6D2sWl0XXp4Bk2mxX59W8+ycx9xmtZJLhWC1pza91093F3XSzfuKmXwdGnIAXG3ZMBb5plvmEBhc7hDx9kALAAEglQClW2wUGBNE4Hmcn7R/2qoYZ1zbDkfO4op9AHHOqsB+8dLASo1DRiyOHkyWjaDLSgJWCKpXANBMPt16K87H/X1b7S8bcSH7mwBWma0gVuuvfePMC67L8t0+8+T1Uk6jmJBotMxn5mK6vfei91zK5o10+hSWMGRVBF7Qy6KFle9wm6mC4pTxq2SZk4Fs0OBQqbVAOaE7KWPh7aSqO7+jUa1IbJKb5S9+2K/pVbGZEePdGVhMZeQ9eLeHJ8RP5Ty1bbsElFchm8abXuvWC5LKU3z5x6x/UXmYc+nNUAcpVY09QoXlg3kH8QTaqrMsgF9hobbh5wtS7pTe/SN7Y14rtSy/g7gazE/bf4EuCiQAfcz2YKJ5a3MGhnVABDewZ/cLl33BQ9lpOxqWEpA6ojDqOUrSTgUaL2JeBi/uykoiWG1Wzd35CJZe1D4707JmcDNywGdMy9p1P4pow0ZTTsbyIQs4t5UQgMSHKU3yrN69bEQOL13L1UCGRDDzbvtLelipdtvA3TybKbxIf6ttC9E5DzbKkWKmuDJJhyE6oN73MDR86uPSf0AQvvbEs4Nh34Dcw9t/9LAsSiLUGugC3Hs4TAbIGotP2JAI4rlP3SWwUJYp7uCoXYwucZA8XM5WxNCnsYpPPVsMDPm725/pw98o2XIyu5PnaMtxcfsrstk+3pdI7vQKaSVYdIFeAuKJvxcrld9KAUaKXwkSGWnV55VoyLbMCw0aO1WVowDEh+tWDifXYcMu2uiyhdPS1Y53kq08jP+7NOJ5+WRW9D4wlAiJBB4yf/jR6aaosIwzX/JeFf2Hzf3D/DczTTWt8DgAA'))
assert hashlib.sha256(RAW).hexdigest()=='de9f10d3b32024796e37ee52f61872a59b954e129d8eca46885c2c24c31590cc'
(ROOT/'selected-prompts.jsonl').write_bytes(RAW)
ROWS=[json.loads(x) for x in RAW.splitlines()]
assert len(ROWS)==10
IDS='cp0001 cp0022 cp0043 cp0064 cp0081 cp0102 cp0123 cp0144 cp0161 cp0182'.split()
SELECTED=[next(r for r in ROWS if r['prompt_id']==i) for i in IDS]
assert all(r['split']=='train' for r in SELECTED) and len({r['category'] for r in SELECTED})==10
CFG={'authorization_revision':2,'source':'kaggle_model_proxy','models':['openai/gpt-5.6-luna','openai/gpt-5.6-terra'],'reasoning_effort':'low','max_completion_tokens':1024,'stream':False,'n':1,'temperature':'omitted_effective_unknown','seed':'omitted_effective_unknown','snapshot':'unknown','system':"Answer the user's request.",'max_requests':20,'target_budget_usd':1,'stop_new_requests_at_confirmed_usd':0.5,'only_existing_free_quota':True,'max_retries':0,'timeout_seconds':180,'sdk_version':'0.6.2','raw_client_reason':'preserve exact response content and full returned metadata; no kbench text transformations'}
CH=hashlib.sha256(json.dumps(CFG,sort_keys=True,separators=(',',':')).encode()).hexdigest()
(ROOT/'config-v2.json').write_text(json.dumps(CFG,indent=2))
ATTEMPTS=[]; TOTAL=0.0; HALTED=False
OUT=ROOT/'responses.jsonl'; JOURNAL=ROOT/'request-journal.jsonl'
def save_line(p,r):
    with open(p,'a') as f:
        f.write(json.dumps(r,ensure_ascii=False)+'\n'); f.flush(); os.fsync(f.fileno())
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run_one(pid,key):
    global TOTAL,HALTED
    assert not HALTED and TOTAL<.50 and len(ATTEMPTS)<20
    idem=pid+'|'+key+'|'+CH
    assert not any(x['idempotency_key']==idem for x in ATTEMPTS)
    row=next(r for r in SELECTED if r['prompt_id']==pid)
    msgs=[{'role':'system','content':CFG['system']},{'role':'user','content':row['prompt']}]
    params={'model':key,'messages':msgs,'reasoning_effort':'low','max_completion_tokens':1024,'stream':False,'n':1}
    record={**row,'request_model':key,'source':'kaggle_model_proxy','config_sha256':CH,'idempotency_key':idem,'messages':msgs,'parameters':{k:v for k,v in params.items() if k!='messages'},'started_utc':utc(),'snapshot':'unknown','status':'started','cost_usd':None}
    ATTEMPTS.append(record); save_line(JOURNAL,record)
    try:
        client=kbench.llms[key].client.with_options(max_retries=0,timeout=180)
        response=client.chat.completions.create(**params)
        raw=response.model_dump(mode='json')
        record.update({'ended_utc':utc(),'raw_response':raw,'returned_model':raw.get('model'),'usage':raw.get('usage'),'status':'received'})
        choices=raw.get('choices') or []
        text=(choices[0].get('message') or {}).get('content') if choices else None
        finish=choices[0].get('finish_reason') if choices else None
        record.update({'text':text,'text_sha256':hashlib.sha256(text.encode()).hexdigest() if isinstance(text,str) else None,'finish_reason':finish,'suspected_truncation':finish=='length','refusal':(choices[0].get('message') or {}).get('refusal') if choices else None})
        usage=raw.get('usage') or {}; cost=usage.get('cost') or {}
        a=cost.get('input_tokens_cost_nanodollars'); b=cost.get('output_tokens_cost_nanodollars')
        if isinstance(a,(int,float)) and isinstance(b,(int,float)) and a>=0 and b>=0:
            record['cost_usd']=(a+b)/1e9; TOTAL+=record['cost_usd']
        record['confirmed_cumulative_usd']=TOTAL
        record['word_count']=len(text.split()) if isinstance(text,str) else None
        record['length_anomaly']=record['word_count'] is not None and not (row['target_words']*.5 <= record['word_count'] <= row['target_words']*1.5)
        same=(raw.get('model') or '').removeprefix('openai/')==key.removeprefix('openai/')
        reasons=[]
        if record['cost_usd'] is None: reasons.append('missing_cost')
        if not same: reasons.append('model_identity_mismatch')
        if not choices or not isinstance(text,str): reasons.append('unexpected_response')
        if finish!='stop': reasons.append('non_stop_finish')
        record['stop_reasons']=reasons; record['status']='saved_stop' if reasons else 'saved'
        save_line(OUT,record); save_line(JOURNAL,record)
        HALTED=bool(reasons) or TOTAL>=.50
    except Exception as e:
        record.update({'ended_utc':utc(),'status':'error_result_uncertain','error_type':type(e).__name__,'error_message':str(e),'stop_reasons':['error_do_not_retry']})
        save_line(JOURNAL,record); HALTED=True
    print('RECORD_JSON_BEGIN'+json.dumps(record,ensure_ascii=False)+'RECORD_JSON_END')
    print('RUN_STATE',json.dumps({'requests':len(ATTEMPTS),'confirmed_cost_usd':TOTAL,'halted':HALTED}))
print('INPUT_VERIFIED',len(ROWS),hashlib.sha256(RAW).hexdigest())
print('SETUP_ONLY_NO_GENERATION')
