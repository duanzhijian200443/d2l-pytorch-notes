"""Supplemental CSV diagnostics only. NOT a replacement for verify_results.py; never writes PASS or ledger."""
import json,hashlib,importlib.util
from pathlib import Path
import pandas as pd,numpy as np
from sklearn.metrics import balanced_accuracy_score
H=Path(__file__).resolve().parent; R=H.parents[1]; S=H/'download-v2/results'; O=H/'partial-analysis';O.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('original_verify',H/'verify_results.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
p=json.loads((H/'payload/protocol.json').read_text()); env=json.loads((S/'environment.json').read_text());assert env['protocol']==p
train=pd.read_csv(R/'train.csv',dtype={'id':str,'prompt_id':str}); folds=pd.read_csv(R/'validation/prompt-group-v1/folds.csv',dtype={'id':str,'prompt_id':str})
assert hashlib.sha256((R/'train.csv').read_bytes()).hexdigest()==p['train_sha256'];assert hashlib.sha256((R/'validation/prompt-group-v1/folds.csv').read_bytes()).hexdigest()==p['input_hashes']['folds.csv']
y=train.model.to_numpy();labels=p['labels'];preds={};dense=[];per=[];fm=[]
for a in p['shares']:
 d=pd.read_csv(S/f'oof-share{a}.csv',dtype={'id':str,'prompt_id':str});assert len(d)==2699 and d.id.nunique()==2699
 for c in ['id','prompt_id','model']: assert d[c].tolist()==train[c].tolist()
 assert d.fold.tolist()==folds.fold.tolist(); pred=d.predicted_model.to_numpy();assert set(pred)<=set(labels);assert d.correct.tolist()==(pred==y).tolist();preds[a]=pred
 dense.append(dict(share=a,ba=float(balanced_accuracy_score(y,pred)),correct=int((pred==y).sum())))
 for lab in labels:
  mask=y==lab;per.append(dict(share=a,model=lab,support=int(mask.sum()),correct=int((pred[mask]==y[mask]).sum()),recall=float((pred[mask]==y[mask]).mean())))
 for fold in range(5):
  mask=folds.fold.eq(fold).to_numpy();fm.append(dict(share=a,fold=fold,ba=float(balanced_accuracy_score(y[mask],pred[mask]))))
reported=pd.read_csv(S/'fold_metrics.csv').set_index(['fold','share']).sort_index();calc=pd.DataFrame(fm).set_index(['fold','share']).sort_index();assert reported.index.equals(calc.index) and np.allclose(reported.ba,calc.ba,rtol=0,atol=1e-12)
groups=sorted(train.prompt_id.unique());base,support=v.matrix_counts(train,preds[.5],groups,labels);draws=np.random.default_rng(42).integers(0,len(groups),size=(2000,len(groups)));den=support[draws].sum(1);assert (den>0).all();paired=[]
for a in [.25,.75]:
 candidate,_=v.matrix_counts(train,preds[a],groups,labels);delta=((candidate[draws].sum(1)-base[draws].sum(1))/den).mean(1);b=preds[.5]==y;c=preds[a]==y
 fd=calc.xs(a,level='share').ba-calc.xs(.5,level='share').ba
 paired.append(dict(share=a,delta_ba=float(balanced_accuracy_score(y,preds[a])-balanced_accuracy_score(y,preds[.5])),bootstrap_low=float(np.quantile(delta,.025)),bootstrap_high=float(np.quantile(delta,.975)),fixed_errors=int((~b&c).sum()),introduced_errors=int((b&~c).sum()),prediction_disagreements=int((preds[a]!=preds[.5]).sum()),positive_folds=int((fd>0).sum()),negative_folds=int((fd<0).sum()),fold_deltas={str(k):float(x) for k,x in fd.items()}))
pd.DataFrame(per).to_csv(O/'csv_per_class.csv',index=False);pd.DataFrame(fm).to_csv(O/'csv_per_fold.csv',index=False)
pc=pd.DataFrame(per).pivot(index='model',columns='share',values='recall');pc['delta25_vs50']=pc[.25]-pc[.5];pc['delta75_vs50']=pc[.75]-pc[.5];pc.to_csv(O/'csv_per_class_deltas.csv')
out=dict(status='PARTIAL_CSV_ONLY_NOT_FULL_ACCEPTANCE',script_version_id=364307522,rows=2699,prompts=len(groups),dense=dense,paired=paired,limitations=['No NPY score matrices; cannot check argmax/finite scores','No fold NPZ; cannot match each fold matrix','No sparse NPZ; pooled sparse metrics cannot be recomputed','Bootstrap conditional on fitted models and these development folds; exploratory, not winner-selection corrected'])
(O/'csv_diagnostics.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2));print(pc.to_string())
